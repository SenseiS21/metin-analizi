import sys
import spacy
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.probability import FreqDist
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import networkx as nx
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                            QHBoxLayout, QPushButton, QLabel, QTextEdit, 
                            QFileDialog, QTextBrowser, QTabWidget, QSplitter,
                            QComboBox, QMessageBox)
from PyQt6.QtCore import Qt
from textblob import TextBlob
import pandas as pd
import numpy as np
from transformers import pipeline
import torch

class AnaPencere(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Gelişmiş Metin Analiz Motoru (CRAE)")
        self.setGeometry(100, 100, 1200, 800)
        
        # NLTK gerekli dosyaları indir
        try:
            nltk.download('punkt')
            nltk.download('stopwords')
            nltk.download('averaged_perceptron_tagger')
        except Exception as e:
            print(f"NLTK indirme hatası: {e}")
        
        merkez_widget = QWidget()
        self.setCentralWidget(merkez_widget)
        ana_layout = QVBoxLayout(merkez_widget)
        
        # Üst kısım için yatay layout
        ust_layout = QHBoxLayout()
        ana_layout.addLayout(ust_layout)
        
        # Sol panel (metin girişi)
        sol_panel = QWidget()
        sol_layout = QVBoxLayout(sol_panel)
        
        # Başlık etiketi
        baslik = QLabel("Metin Girişi")
        baslik.setAlignment(Qt.AlignmentFlag.AlignCenter)
        baslik.setStyleSheet("font-size: 24px; font-weight: bold; margin: 15px;")
        sol_layout.addWidget(baslik)
        
        # Metin giriş alanı
        self.metin_alani = QTextEdit()
        self.metin_alani.setPlaceholderText("Metinlerinizi buraya yapıştırın veya yazın...")
        self.metin_alani.setStyleSheet("font-size: 16px; padding: 10px; border: 1px solid #ccc; border-radius: 5px;")
        sol_layout.addWidget(self.metin_alani)
        
        # Butonlar için yatay layout
        buton_layout = QHBoxLayout()
        sol_layout.addLayout(buton_layout)
        
        # Kaydet butonu
        kaydet_butonu = QPushButton("Metni Kaydet")
        kaydet_butonu.setStyleSheet("""
            QPushButton {
                background-color: #007bff;
                color: white;
                padding: 10px 20px;
                border: none;
                border-radius: 5px;
                font-size: 16px;
                margin: 5px;
            }
            QPushButton:hover {
                background-color: #0056b3;
            }
        """)
        kaydet_butonu.clicked.connect(self.metni_kaydet)
        buton_layout.addWidget(kaydet_butonu)
        
        # Yükle butonu
        yukle_butonu = QPushButton("Metni Yükle")
        yukle_butonu.setStyleSheet("""
            QPushButton {
                background-color: #28a745;
                color: white;
                padding: 10px 20px;
                border: none;
                border-radius: 5px;
                font-size: 16px;
                margin: 5px;
            }
            QPushButton:hover {
                background-color: #218838;
            }
        """)
        yukle_butonu.clicked.connect(self.metni_yukle)
        buton_layout.addWidget(yukle_butonu)
        
        # Analiz butonu
        analiz_butonu = QPushButton("Metni Analiz Et")
        analiz_butonu.setStyleSheet("""
            QPushButton {
                background-color: #ffc107;
                color: black;
                padding: 10px 20px;
                border: none;
                border-radius: 5px;
                font-size: 16px;
                margin: 5px;
            }
            QPushButton:hover {
                background-color: #e0a800;
            }
        """)
        analiz_butonu.clicked.connect(self.metni_analiz_et)
        buton_layout.addWidget(analiz_butonu)
        
        ust_layout.addWidget(sol_panel)
        
        # Sağ panel (analiz sonuçları)
        sag_panel = QWidget()
        sag_layout = QVBoxLayout(sag_panel)
        
        # Tab widget'ı
        self.tab_widget = QTabWidget()
        
        # Temel Analiz sekmesi
        temel_analiz_tab = QWidget()
        temel_layout = QVBoxLayout(temel_analiz_tab)
        self.analiz_cikti_alani = QTextBrowser()
        self.analiz_cikti_alani.setStyleSheet("font-size: 14px; padding: 10px; border: 1px solid #ccc; border-radius: 5px; background-color: #f8f9fa; color: black;")
        temel_layout.addWidget(self.analiz_cikti_alani)
        self.tab_widget.addTab(temel_analiz_tab, "Temel Analiz")
        
        # Anahtar Kelimeler sekmesi
        anahtar_kelimeler_tab = QWidget()
        anahtar_layout = QVBoxLayout(anahtar_kelimeler_tab)
        self.anahtar_kelimeler_alani = QTextBrowser()
        self.anahtar_kelimeler_alani.setStyleSheet("font-size: 14px; padding: 10px; border: 1px solid #ccc; border-radius: 5px; background-color: #f8f9fa; color: black;")
        anahtar_layout.addWidget(self.anahtar_kelimeler_alani)
        self.tab_widget.addTab(anahtar_kelimeler_tab, "Anahtar Kelimeler")
        
        # Duygu Analizi sekmesi
        duygu_analizi_tab = QWidget()
        duygu_layout = QVBoxLayout(duygu_analizi_tab)
        self.duygu_analizi_alani = QTextBrowser()
        self.duygu_analizi_alani.setStyleSheet("font-size: 14px; padding: 10px; border: 1px solid #ccc; border-radius: 5px; background-color: #f8f9fa; color: black;")
        duygu_layout.addWidget(self.duygu_analizi_alani)
        self.tab_widget.addTab(duygu_analizi_tab, "Duygu Analizi")
        
        # Özetleme sekmesi
        ozetleme_tab = QWidget()
        ozetleme_layout = QVBoxLayout(ozetleme_tab)
        self.ozetleme_alani = QTextBrowser()
        self.ozetleme_alani.setStyleSheet("font-size: 14px; padding: 10px; border: 1px solid #ccc; border-radius: 5px; background-color: #f8f9fa; color: black;")
        ozetleme_layout.addWidget(self.ozetleme_alani)
        self.tab_widget.addTab(ozetleme_tab, "Özetleme")
        
        sag_layout.addWidget(self.tab_widget)
        ust_layout.addWidget(sag_panel)
        
        # Durum etiketi
        self.durum_etiketi = QLabel("")
        self.durum_etiketi.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.durum_etiketi.setStyleSheet("font-size: 14px; color: #555; margin-top: 10px;")
        ana_layout.addWidget(self.durum_etiketi)
        
        # spaCy modelini yükle
        try:
            self.nlp = spacy.load("./tr_core_news_md/tr_core_news_md-3.4.2")
            print("spaCy Türkçe modeli başarıyla yüklendi.")
            self.durum_etiketi.setText("spaCy Türkçe modeli başarıyla yüklendi.")
        except Exception as e:
            self.nlp = None
            hata_mesaji = f"spaCy Türkçe modeli yüklenirken hata oluştu: {e}"
            print(hata_mesaji)
            self.durum_etiketi.setText(hata_mesaji)
        
        # Transformers modellerini yükle
        try:
            self.summarizer = pipeline("summarization", model="ozcangundes/mt5-small-turkish-summarization")
            self.sentiment_analyzer = pipeline("sentiment-analysis", model="savasy/bert-base-turkish-sentiment-cased")
        except Exception as e:
            print(f"Transformers modelleri yüklenirken hata: {e}")
            self.summarizer = None
            self.sentiment_analyzer = None
    
    def metni_kaydet(self):
        dosya_adi, _ = QFileDialog.getSaveFileName(self, "Metin Dosyasını Kaydet", "", "Metin Dosyaları (*.txt);;Tüm Dosyalar (*)")
        if dosya_adi:
            try:
                with open(dosya_adi, 'w', encoding='utf-8') as f:
                    f.write(self.metin_alani.toPlainText())
                self.durum_etiketi.setText(f"Metin başarıyla kaydedildi: {dosya_adi}")
            except Exception as e:
                self.durum_etiketi.setText(f"Metin kaydedilirken hata oluştu: {e}")

    def metni_yukle(self):
        dosya_adi, _ = QFileDialog.getOpenFileName(self, "Metin Dosyasını Yükle", "", "Metin Dosyaları (*.txt);;Tüm Dosyalar (*)")
        if dosya_adi:
            try:
                with open(dosya_adi, 'r', encoding='utf-8') as f:
                    icerik = f.read()
                self.metin_alani.setText(icerik)
                self.durum_etiketi.setText(f"Metin başarıyla yüklendi: {dosya_adi}")
            except Exception as e:
                self.durum_etiketi.setText(f"Metin yüklenirken hata oluştu: {e}")

    def metni_analiz_et(self):
        if not self.nlp:
            QMessageBox.critical(self, "Hata", "spaCy Türkçe modeli yüklenemedi. Lütfen kurulumu kontrol edin.")
            return
        
        metin = self.metin_alani.toPlainText()
        if not metin.strip():
            QMessageBox.warning(self, "Uyarı", "Lütfen analiz etmek için bir metin girin.")
            return

        # Temel Analiz
        doc = self.nlp(metin)
        cikti = []
        cikti.append("<h3>Adlandırılmış Varlıklar (NER):</h3>")
        if doc.ents:
            for ent in doc.ents:
                cikti.append(f"<li><b>{ent.text}</b> ({ent.label_})</li>")
        else:
            cikti.append("<li>Metinde adlandırılmış varlık bulunamadı.</li>")

        cikti.append("<h3>Cümleler:</h3>")
        for i, sent in enumerate(doc.sents):
            cikti.append(f"<li>Cümle {i+1}: {sent.text}</li>")
        
        cikti.append("<h3>Kelime Türleri (POS):</h3>")
        for token in doc:
            if token.pos_:
                cikti.append(f"<li><b>{token.text}</b> ({token.pos_})</li>")

        self.analiz_cikti_alani.setHtml("\n".join(cikti))
        
        # Anahtar Kelimeler
        self.anahtar_kelimeleri_bul(metin)
        
        # Duygu Analizi
        self.duygu_analizi_yap(metin)
        
        # Özetleme
        self.metni_ozetle(metin)
        
        self.durum_etiketi.setText("Metin analizi tamamlandı.")

    def anahtar_kelimeleri_bul(self, metin):
        # NLTK ile anahtar kelimeleri bul
        tokens = word_tokenize(metin.lower())
        stop_words = set(stopwords.words('turkish'))
        filtered_tokens = [word for word in tokens if word.isalnum() and word not in stop_words]
        
        fdist = FreqDist(filtered_tokens)
        anahtar_kelimeler = fdist.most_common(10)
        
        cikti = ["<h3>En Sık Kullanılan Kelimeler:</h3>"]
        for kelime, frekans in anahtar_kelimeler:
            cikti.append(f"<li><b>{kelime}</b>: {frekans} kez</li>")
        
        self.anahtar_kelimeler_alani.setHtml("\n".join(cikti))

    def duygu_analizi_yap(self, metin):
        if self.sentiment_analyzer:
            try:
                sonuc = self.sentiment_analyzer(metin)[0]
                cikti = ["<h3>Duygu Analizi Sonucu:</h3>"]
                cikti.append(f"<p>Duygu: <b>{sonuc['label']}</b></p>")
                cikti.append(f"<p>Güven Oranı: <b>{sonuc['score']:.2f}</b></p>")
            except Exception as e:
                cikti = [f"<p>Duygu analizi yapılırken hata oluştu: {e}</p>"]
        else:
            cikti = ["<p>Duygu analizi modeli yüklenemedi.</p>"]
        
        self.duygu_analizi_alani.setHtml("\n".join(cikti))

    def metni_ozetle(self, metin):
        if self.summarizer:
            try:
                ozet = self.summarizer(metin, max_length=130, min_length=30, do_sample=False)
                cikti = ["<h3>Metin Özeti:</h3>"]
                cikti.append(f"<p>{ozet[0]['summary_text']}</p>")
            except Exception as e:
                cikti = [f"<p>Özetleme yapılırken hata oluştu: {e}</p>"]
        else:
            cikti = ["<p>Özetleme modeli yüklenemedi.</p>"]
        
        self.ozetleme_alani.setHtml("\n".join(cikti))

if __name__ == '__main__':
    uygulama = QApplication(sys.argv)
    pencere = AnaPencere()
    pencere.show()
    sys.exit(uygulama.exec()) 